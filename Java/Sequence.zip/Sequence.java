/*
Wesley Dillingham
Java For Programmers 
Problem 2
*/


import java.lang.*;

public class Sequence
{

	public static void main (String[] args)
	{
	
		int NthTerm = Integer.parseInt(args[0]);
				
	
	
		
	
				
				
				
				
		
						if (!(NthTerm > 2) || (NthTerm > 40))	//check to see if the value falls in the correct range
						{
							System.out.println("Invalid Number Please input a number greater than 2 and less than or equal to forty");
							
						}
						else
						{
								
										
										int x1 = 1; //previous number
										int x2 = 1;
										int x = 0;
										
										System.out.print(x1 + " " + x2 + " ");//output the default first two "1's"
										
										
										
									// here we iterate through each term until we get to the nth term	
									for (int currentTerm = 2; currentTerm < NthTerm; currentTerm++)
									{
											x = x1 + x2;
											
											//this checks to see if the current term is a factor of ten, if so we print a new line
											if (!((currentTerm+1) % 10 == 0))
											{
											System.out.print(x + " ");
											}
											else
											{
											System.out.println(x + " ");
											}
											
											
											x2 = x1;
											x1 = x;					
									}//end for (int currentTerm
			
			}//end else
	}
	
	
}