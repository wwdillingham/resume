/*
*
 * Wesley Dillingham
 * Java For Programmers - Fall 2008
 * 
 * 
*/

package creditcard;

import java.util.*;

public class TestDebt {
    
    //MAIN
    public static void main(String[] args) {
        
        
        double Principal, Rate ;
        
         Scanner keyboard = new Scanner(System.in);
         
         do{  //get and encapsulate user input
             
             System.out.println("Please enter a principal debt amount greater than zero and less than 10,000: ");
             Principal = keyboard.nextDouble();
             System.out.println("Please enter your interest rate, greater than zero and less than 25% (for 17.99% enter '17.99' etc):  ");
             Rate = keyboard.nextDouble();
             
             if(Principal <= 0 || Principal >= 10000 || Rate <= 0 || Rate >= 25)
             {
                 System.out.println("There was an error with your input, please try again");
             }
             
         }while (Principal <= 0 || Principal >= 10000 || Rate <= 0 || Rate >= 25);
        
        Debt myDebt = new Debt(Principal, Rate); //create new object with user inputed parameters
        
        
        
        int month = 1;  
        for( ; myDebt.GetCurrentPrincipal() > 0; month++) 
       {
            
           
           myDebt.makePayment();
           myDebt.calculateInterest();
           System.out.println("Current Month: " + month);
           System.out.println("Current Principal: $" + truncate(myDebt.GetCurrentPrincipal()));
           System.out.println("Current Interest: $" + truncate(myDebt.GetTotalPayment()));
           System.out.println("Payment amount: $" + truncate(myDebt.GetMinimumPayment()));
           System.out.println("");
               
        
       } //end for(int month = 1
        
        //output the final tallies
        System.out.println("Months to pay off Debt: " + (month-1));
        System.out.println("Total interest payed: $" + truncate(myDebt.GetTotalPayment()));
        System.out.println("Total amount payed: $" + truncate((myDebt.GetTotalPayment()+Principal)));
        
    }//end main
    
  private static double truncate(double x)  // I could not open the included formatter class so i used this logic instead
{
    long y=(long)(x*100);
    return (double)y/100;
}

}


