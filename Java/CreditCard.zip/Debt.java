/*
 * 
 * Wesley Dillingham
 * Java For Programmers - Fall 2008
 * Due 9/22/08
 * 
 * This class represents the actual credit card debt it keeps track of the current principal
 * the interest rate the minimum payment and how much interest has been paid over the life of the loan
 * 
 */

package creditcard;


public class Debt {
    
    //************* Fields *******************
    protected double currentPrincipal;
    protected double interestRate;
    protected double minimumPayment;
    protected double totalPayment; //interest payment made over the liftime of the loan.
 
    

    
//***************** Constructor ************
public Debt(double currentPrincipal_, double interestRate_)
{
    currentPrincipal = currentPrincipal_;
    interestRate = interestRate_;
}






//************* Accessors ***************
public double GetTotalPayment()
{
    return totalPayment;
}

public double GetMinimumPayment()
{
    return minimumPayment;
}

public double GetInterestRate()
{
    return interestRate;
}

public double GetCurrentPrincipal()
{
    return currentPrincipal;
}





//******************* Mutators ****************

public void makePayment() //calculates the minimum payment and subtracts it from the principal
{
    
    if (currentPrincipal > 20) //isolate the portion that doesnt need to be rounded to the whole number
    {
        minimumPayment = (.02 * currentPrincipal);
        minimumPayment = minimumPayment - (minimumPayment % 1);
        if(minimumPayment == 0) //minimum payments of less than a dollar round up to 1 dollar
        {
            minimumPayment = 1;
        }
    }
    else
    {
        minimumPayment = currentPrincipal;
    }
    
    currentPrincipal -= minimumPayment; //subtrat minimum payment from 
   
} //end makePayment()

//calculates the interest for an entire month (3o days) and updates the principal
public void calculateInterest() 
{
    double dir = interestRate / 365; //daily interest rate
    double dailyInterest;
    
    for (int day = 0; day < 30; day++) //adds the daily interest to the current principal 30 times
    {
            
            dailyInterest = ((dir/100) * currentPrincipal);
            currentPrincipal += dailyInterest;
            totalPayment += dailyInterest;
                    
            
    }
    
}


}


