//wesley dillingham
//java for programmers assignmetn 3 on test 3
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;

public class FileLister
{

	//create all the portions of the gui
	private JFrame f = new JFrame("File Lister");
	private JPanel pnlNorth = new JPanel();
	private JButton btnNorth = new JButton("List Files");
	private JTextArea txtSouth = new JTextArea();
	
	public FileLister()
						{
							pnlNorth.add(btnNorth);
							f.getContentPane().setLayout(new BorderLayout());
							f.getContentPane().add(pnlNorth, BorderLayout.NORTH);
							f.getContentPane().add(txtSouth, BorderLayout.CENTER);
							
							btnNorth.addActionListener(new ActionListener()
							{
					
							public void actionPerformed(ActionEvent e)
							{
							
							File dir = new File("C:\\Users\\ITAdmin\\Desktop"); // read in the current directory
							File[] files = dir.listFiles();
													
									for( int i = 0; i < files.length; i++ )
									{
												
											txtSouth.append(files[i].getName());
																	
											System.out.println( files[i].getName() );
									}
							
							
							}
							}
							);
							
						}
	

	//main
	public static void main(String args[])
	{
		FileLister fl = new FileLister();
		fl.launchFrame();
	}
	
	public void launchFrame()
				{	
				
			
					f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					f.pack();
					f.setVisible(true);
					
			
				}
	


}

