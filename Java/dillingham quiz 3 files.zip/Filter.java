//Wesley Dillingham
//Quiz 3 problem 1
//JAVA for Programers

import java.io.*; //imported to allow file io

public class Filter
{
	public static void main(String args[])
	{
	
		FileWriter fw = null; //declare the filewrtier
		
		try //encapsulate any errors from creating the file
		{
			fw = new FileWriter("novowels.txt");
		}
		catch (IOException ioe)
		{
			System.out.println("Error creating file");
			System.exit(1);
		}
	
		FileReader fr = null; //create the file reader
		
		try //encapsulate any errors from opening and reading input file
		{
			fr = new FileReader("TOTC.txt");
			int myChar;
			while( ( myChar = fr.read() ) != -1)//traverse the file
			{
				char c = (char)myChar;
			//	System.out.print(c);
					
					//this is where we check to see if it is a vowel, if it is WE dont write to file
					if(c != 'a' && c != 'A' && c != 'e' && c != 'E' && c != 'i' && c != 'I' && c != 'o' && c != 'O' && c != 'u' && c != 'U')
					{
						fw.write(c);
						fw.flush();
					}
			}
		}
		catch (IOException ioe)
		{
			System.out.println("there was an io exception");
			System.exit(2);
		}	
	}
}