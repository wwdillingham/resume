// This class will be used to extract individual lines of data
// from the survey data files. (Look at the code for MakeSurvey.java
// for details on the file layout and to see how the data is created.)
//
// You will need to use this class to create an object that will return
// the individual lines of the file as String objects. Parsing the lines into
// individual values will be part of your responsibility.
//
// Author: Kevin Bierre
// Date:   April 1, 2001
// Updated:Sept 24,2001

import java.io.*;

public class SurveyData{
	String fileName;
	BufferedReader pin;
	
	// constructor
	public SurveyData(String fn) {
		fileName = fn;
	}
	
	// open the file for use - exits the program if there is a
	// problem opening the file
	private void openFile() {
		FileReader fr = null;
		try {
			fr = new FileReader(fileName);
		}
		catch(IOException e) {
			System.out.println("Cannot open " + fileName + " for input");
			System.exit(1);			
		}
		pin = new BufferedReader(fr);
	}
	
	// assuming a file was opened, close it now
	public void closeFile() {
		try {
			if (pin != null)
				pin.close();
		}
		catch(IOException ioe) {
			// do nothing
		}
	}
	
	// Reads the next line of data from the file. When out
	// of data, returns a reference value of null. Note that
	// end of line characters are removed from the String already.
	public String getData() {
		String line = null;
		try {
			if (pin == null) { // file not opened yet
				openFile();  // so open it now
			}
			// Get a line of data and return it
			line = pin.readLine();
		}
		catch(IOException ioe) {
			System.out.println("Unable to read from survey data file");
			System.exit(2);
		}
		return line; // send back a line from the file
	}
}