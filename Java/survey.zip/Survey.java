/*
wesley dillingham
Java for programmers
this class tabulates survey results created by makesurvey 
this program utilizes the surveydata class to read lines of data out of survey.txt
*/
//import java.io.*;
import java.util.*;

public class Survey
{
   public static void main (String[] args)
   {

		  
		    	   //open input file
				   SurveyData mySurvey = new SurveyData("survey.txt");
		   
			   		
						
			int numQuestions=0; 
			String answer;					
			
			
			String line = mySurvey.getData(); //invoke the getdata function (read in a line)
			
			//tokenize the line string, remove the commas
			StringTokenizer testToken = new StringTokenizer(line, ","); //read in the first or next  line
			
			
			numQuestions = testToken.countTokens();//determine the number of questions 
				
			int data[][] = new int[numQuestions][5]; //the number of questions by the number of possible responses (abcde)				
			int count = 0;
			
			
				while(line != null) //loop through each line of answers until you reach the end
				{		
						
						int curQuestion = 0;
						
							while(testToken.hasMoreTokens())//each line has ten questions or tokens, loop until we reach the end of the line
							{
								
								
								answer = testToken.nextToken(); //set a string variable equal to the comma seperated value /token
															
								//enter a if structure which keeps track of whether the answer was an a b c d or e
								if(answer.charAt(0) == 'A')
								{
									data[curQuestion][0]++;
								}
							  if(answer.charAt(0) == 'B')
								{
									data[curQuestion][1]++;
								}
							   if(answer.charAt(0) == 'C') 
								{
								data[curQuestion][2]++;
								}
							   if(answer.charAt(0) == 'D')
								{
									data[curQuestion][3]++;
								}
								 if(answer.charAt(0) == 'E')
								{
									data[curQuestion][4]++;
								}

								curQuestion++;
							
							} //end while .hasMoreTokens
							
					//	 System.out.println("printing line: " + line);
						
					    line = mySurvey.getData(); //get the next line
						
						if (line != null) //keeps us from trying to tokenize a null string
						{		 
					    testToken =  new StringTokenizer(line, ","); //read in the first or next  line
						}
						//count++;
						
					}
					
					
	//Now we will handle output
	
										
		for(int curQuestion = 0; curQuestion < numQuestions; curQuestion++)
		{
		
				System.out.println("Question " + (curQuestion + 1) + " A: " + data[curQuestion][0] + " B: " + data[curQuestion][1] + " C: " + data[curQuestion][2] + " D: " + data[curQuestion][3] + " E: " + data[curQuestion][4]);
		
		}								
										
										
				 
				 
		 
				 
	  }//end main
    
    
    
}
        
        
   