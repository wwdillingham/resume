/*
 * 
 * Wesley Dillingham
 * Java For Programmers
 * Prof. Andreotta
 * RIT Fall 2008
 * 
 * Implements a trajectory class, which computes time till impact, distance 
 traveled, maximum height, and speed on impact. It also displays its current 
 * x and y positions at each second in flight as well as its x and y velocities
 * 
 */ 

package trajectory;

import java.math.*;

public class Trajectory {
    
    
    protected double initialVelocity, firingAngle, Vx, Vy;
    protected double Vo_x; // velocity original in the x dimension
    protected double Vo_y; //Velocity original in the y dimension
    protected double Px, Py; //position from 0 in the given dimension
    public double gravity = 9.81;
    public double deltaT = .01; // change in time

    //***************** Constructor ************
public Trajectory(double initialVelocity_, double firingAngle_)
{
    initialVelocity = initialVelocity_;
    firingAngle = firingAngle_;
    
    Vo_x = initialVelocity_ * Math.cos(Math.toRadians(firingAngle_)); // a constant attribute
    Vo_y = initialVelocity_ * Math.sin(Math.toRadians(firingAngle_)); // a constant attribute
    Vx = initialVelocity_* Math.cos(Math.toRadians(firingAngle_)); //value will be updated as program runs
    Vy = initialVelocity_ * Math.sin(Math.toRadians(firingAngle_)); // value will be updated as program runs
    Py = 0;
    Px = 0;
}

        //************ Mutators ******************
        public double velocityY()
        {
            Vy = Vy - gravity * deltaT;
            return Vy;
        }

        public double positionY()
        {
             Py = Py + Vy * deltaT;
             return Py;

        }

        public double positionX()
        {
              Px = Px + Vx * deltaT;
              return Px;
        }
        
     
        //*************** Accessors *****************
public double GetfiringAngle()
{
    return firingAngle;
}
public double GetinitialVelocity()
{
    return initialVelocity;
}
public double GetPx()
{
    return Px;
}
public double GetPy()
{
    return Py;
}
public double GetVy()
{
    return Vy;
}
public double GetVx()
{
    return Vx;
}              
public double GetVo_y()
{
    return Vo_y;
}        
public double GetVo_x()
{
    return Vo_x;
}


} //end class
