/*
 * 
 * 
 * Wesley Dillingham
 * Java For Programmers
 * Prof. Andreotta
 * RIT Fall 2008
 * 
 * Implements a trajectory class, which computes time till impact, distance 
 traveled, maximum height, and speed on impact. It also displays its current 
 * x and y positions at each second in flight as well as its x and y velocities
 * 
 */

package trajectory;

import java.util.*;



public class TestTrajectory {
    
    public static void main(String[] args)
    {
        
        double Vo; // set to what user enteres for firing speed (velocity original)
        double firingAngle; // set to what the user enteres for firing angle
        double impactTime = 0;
        double distanceTraveled = 0;
        double maxHeight = 0;
        double speedOnImpact = 0;
       // double seconds = 0;
        
        
        Scanner keyboard = new Scanner(System.in);
        
        
        
        // get input from the user 
        do{

            System.out.println("Welcome to the Trajectory Program");
            System.out.println("Please enter the firing speed in meters per second [0-5,000 exclusive]: ");
            Vo = keyboard.nextDouble();
            System.out.println("Please enter the firing angle [0-90 exclusive]");
            firingAngle = keyboard.nextDouble();

        
          }while(firingAngle <= 0 || firingAngle >= 90 || Vo <= 0 || Vo >= 5000); //end do loop (encapsulates input)
     
        
        
        
        Trajectory launch = new Trajectory(Vo, firingAngle); //create object named launch
        
        System.out.println("You entered: (Firing Speed: " + launch.GetinitialVelocity() + " m/s, Firing Angle: " + launch.GetfiringAngle() + ")."); 
             
        impactTime = ((Vo * Math.sin(Math.toRadians(firingAngle)))/launch.gravity)*2;
        distanceTraveled = launch.GetVo_x() * impactTime; //d = rt
        speedOnImpact = launch.GetVo_y() + -1*launch.gravity*(impactTime);
        
        
        
         
            //outer loop is for seconds
            //inner loop is for milliseconds with t as the variable
            for (double seconds = 0; seconds <= impactTime; seconds++)
            {
                    for(double t = 0; t < 100; t++)
                    {
                                    
                             if (t % 100 == 0) //print out the results ever 100 times or on each whole second
                             {
                             System.out.println("Time: " + seconds + " X: " + truncate(launch.positionX())  + " Y: " + truncate(launch.positionY())  + " Vel X: " + truncate(launch.GetVx())  + " Vel Y: " + truncate(launch.velocityY()) );
                             }
                             
                             else // even if we arent printing we need to continue calculating each millisecond
                             {
                                 launch.positionX();
                                 launch.positionY();
                                 launch.velocityY();

                             }

                            if(maxHeight < launch.GetPy()) //simply keeps track of max height acheived
                            {
                                maxHeight = launch.GetPy();
                            }
                            
                        
                    }//end milliseconds
        
            } //end seconds for loop
        
       
        System.out.println("");
        System.out.println("Impact time:        " + truncate(impactTime));
        System.out.println("Distance Traveled:  " + truncate(distanceTraveled));
        System.out.println("Maximum Height:     " + truncate(maxHeight));
        System.out.println("Speed on Impact:    " + truncate(speedOnImpact));
       

    } //end main
    
      private static double truncate(double x)  // I could not open the included formatter class so i used this logic instead
{
    long y=(long)(x*100);
    return (double)y/100;
}
    
    
}//end class
