//Wesley Dillingham
//Java For programmers
//quiz 4

public class BickerThread extends Thread
{
	private String msg;


	private boolean KeepRunning = true;
	
	public BickerThread(String msg) //constructor
	{
		this.msg = msg;
	}
	
	public void die()
	{
		KeepRunning = false;
	}
	public void run()
	{
		for (int i = 0; i < 5; i++)
		{
						if(!KeepRunning)
						{
							return;
						}
						
			System.out.println(msg);
			try{ sleep(100); } catch(InterruptedException ie){System.out.println("Error handled");}
			
		}
		

	}
	
}

/*

public class BickerThread extends Thread
{
	private String msg;


	private boolean KeepRunning = true;
	
	public BickerThread(String msg) //constructor
	{
		this.msg = msg;
	}
	
	public void die()
	{
		KeepRunning = false;
	}
	public void run()
	{
		for (int i = 0; i < 5; i++)
		{
						if(!KeepRunning)
						{
							return;
						}
						
			System.out.println(msg);
			try{ sleep(100); } catch(InterruptedException ie){System.out.println("Error handled");}
			
		}
		
					ParentThread p1 = new ParentThread("Knock it off");
					p1.start();
	}
	
}

*/