//Wesley Dillingham
//Java For programmers
//quiz 4


public class MrThread
{
	public static void main(String[] args)
	{
	
		ParentThread p1 = new ParentThread("Knock it off");
		p1.start();
		
		
		
	}	

} 



/*

public class MrThread
{
	public static void main(String[] args)
	{
		BickerThread b1 = new BickerThread("Is so ");
		BickerThread b2 = new BickerThread("Is not");
		
		try
		{
		b1.start();
		b2.start();
		}
		catch(Exception e)
		{
			System.out.println("exception caught");
		}
		
	}	

} 

*/