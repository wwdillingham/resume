//Wesley Dillingham
//Quiz 4
//Part 1

import java.io.*;
import java.net.*;
import java.util.*;


public class PalClient
{
	public static void main(String[] args)
	{
			try{
					// you said it was OK to hard wire this in
					Socket sock = new Socket("10.100.150.164", 7734);
					
					Scanner keyboard = new Scanner(System.in);
					
					String input = keyboard.nextLine();
					System.out.println("The user entered: " + input);
					
							
					//Send the String to the server
					OutputStream os = sock.getOutputStream();
					OutputStreamWriter osw = new OutputStreamWriter(os);
					BufferedWriter bw = new BufferedWriter(osw);
					
					bw.write(input + "\r\n");
					bw.flush();
					
					//Get response
					InputStream is = sock.getInputStream();
					InputStreamReader isr = new InputStreamReader(is);
					BufferedReader br = new BufferedReader(isr);
					
					System.out.println("The Server Says: " + br.readLine());	
					sock.close();
				 }
				 catch (Exception e)
				 {
				 	System.out.println("Exception Thrown ");
				 }
			
	}
}