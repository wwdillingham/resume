//Wesley Dillingham
//Java for Programmers quiz 4


public class ParentThread extends Thread
{
	private String msg;
	private boolean KeepRunning = true;
	
	public ParentThread(String msg) //constructor
	{
		this.msg = msg;
	}
	
	public void die()
	{
		KeepRunning = false;
	}
	public void run()
	{
			
		BickerThread b1 = new BickerThread("Is so ");
		BickerThread b2 = new BickerThread("Is not");
		
		try
		{
		b1.start();
		b2.start();
		}
		catch(Exception e)
		{
			System.out.println("exception caught");
		}
		
	
		System.out.println(msg);

	
	}
	
}




/*

public class ParentThread extends Thread
{
	private String msg;
	private boolean KeepRunning = true;
	
	public ParentThread(String msg) //constructor
	{
		this.msg = msg;
	}
	
	public void die()
	{
		KeepRunning = false;
	}
	public void run()
	{
			System.out.println(msg);
	
	}
	
}

*/